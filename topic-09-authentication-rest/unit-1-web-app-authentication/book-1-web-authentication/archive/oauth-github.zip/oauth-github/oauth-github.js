'use strict';

const os = require('os');
os.tmpDir = os.tmpdir;

const Hapi = require('hapi');
const Bell = require('bell');
const AuthCookie = require('hapi-auth-cookie');

const main = async () => {

  const server = Hapi.server({ port: 3000 });

  // Register bell and hapi-auth-cookie with the server
  await server.register([Bell, AuthCookie]);

  var authCookieOptions = {
    password: 'cookie-encryption-password-secure', // String used to encrypt auth cookie (min 32 chars)
    cookie: 'demo-auth',   // Name of cookie to set
    isSecure: false        // Should be 'true' in production software (requires HTTPS)
  };

  server.auth.strategy('cookie-auth', 'cookie', authCookieOptions);

  var bellAuthOptions = {
    provider: 'github',
    password: 'github-encryption-password-secure', // String used to encrypt temporary cookie
    // used during authorisation steps only
    clientId: 'ENTER CLIENT ID',          // *** Replace with your app Client Id ****
    clientSecret: 'ENTER CLIENT SECRET',  // *** Replace with your app Client Secret ***
    isSecure: false        // Should be 'true' in production software (requires HTTPS)
  };

  server.auth.strategy('github-oauth', 'bell', bellAuthOptions);

  server.auth.default('cookie-auth');

  //Set up the routes
  server.route([
    {
      method: 'GET',
      path: '/login',
      config: {
        auth: 'github-oauth',
        handler: function (request, h) {
          if (request.auth.isAuthenticated) {
            request.cookieAuth.set(request.auth.credentials);
            return ('Hello ' + request.auth.credentials.profile.displayName);
          }
          return('Not logged in...');
        }
      }
    }, {
      method: 'GET',
      path: '/account',
      config: {
        auth: 'cookie-auth',
        handler: function (request, h) {
          if (request.auth.isAuthenticated) {
            return(request.auth.credentials.profile);
          }
        }
      }
    }, {
      method: 'GET',
      path: '/userinfo',
      config: {
        auth: 'cookie-auth',
        handler: function (request, h) {
          if (request.auth.isAuthenticated) {
            return('<h2>From your GitHub profile</h2>'
            + '<b>User name:</b> ' + request.auth.credentials.profile.username
            + '<br><b>Display name:</b> ' + request.auth.credentials.profile.displayName
            + '<br><b>Email address:</b> ' + request.auth.credentials.profile.email
            + '<br><b>Affiliation:</b> ' + request.auth.credentials.profile.raw.company);
          }
        }
      }
    }, {
      method: 'GET',
      path: '/',
      config: {
        auth: {
          mode: 'optional'
        },
        handler: function (request, h) {
          if (request.auth.isAuthenticated) {
            return ('Hello ' + request.auth.credentials.profile.displayName);
          }
          return('Hello stranger!');
        }
      }
    }, {
      method: 'GET',
      path: '/logout',
      config: {
        auth: false,
        handler: function (request, h) {
          request.cookieAuth.clear();
          return('Logged out now!');
        }
      }
    }
  ]);

  // Start the server
  await server.start()

  return server;
};

main()
.then((server) => console.log(`Server listening on ${server.info.uri}`))
.catch((err) => {
  console.error(err);
  process.exit(1);
});
